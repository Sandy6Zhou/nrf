#include "device_config.h"
#include "FM175XX.h"
#include "uart.h"
#include "type_b.h"
#include <string.h>
#include "type_b_app.h"



unsigned char TYPE_B_APP(void)
{
	unsigned char rece_len;
	unsigned char rece_buff[64],UID[64];
    
    FM175XX_SoftReset();
	Pcd_ConfigISOType(1);//ѡ��TYPE Bģʽ

	Set_Rf(3);   //ѡ��TX1��TX2���
	if(TypeB_Request(&rece_len,rece_buff,&PICC_B)==FM17_ERR)
		return FM17_ERR;
    printf("------------------------------------------\r\n");
	printf("-> TYPE B Request\r\n");
    printf("-> ATQB = ");
	printf_array(rece_buff,rece_len);


	if(TypeB_Select(PICC_B.PUPI,&rece_len,rece_buff)==FM17_ERR)
		return FM17_ERR;
	printf("-> TYPE B AttriB\r\n");
	printf("-> Return = ");
	printf_array(rece_buff,rece_len);

	if(TypeB_GetUID(&rece_len,UID)==FM17_ERR)
  	return FM17_ERR;
	printf("-> Get UID of type B.\r\n");
	printf("-> Return = ");
	printf_array(UID,rece_len);
    Status_LED_Blink();
	Set_Rf(0);   //�ر�TX1��TX2���
	return FM17_OK;

}




