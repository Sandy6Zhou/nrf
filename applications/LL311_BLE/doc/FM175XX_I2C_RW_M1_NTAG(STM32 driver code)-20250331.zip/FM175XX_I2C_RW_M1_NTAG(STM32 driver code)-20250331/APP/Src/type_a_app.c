#include "device_cfg.h"
#include "FM175XX.h"
#include "uart.h"
#include "systick.h"
#include <string.h>
#include "ReaderApi.h"
#include "Mifare.h"
#include "NTag.h"
#include "type_a_app.h"


void Mifare_App( void )
{
    unsigned char result;    
//    unsigned char i,j,k; 
//    unsigned char block_buff[16] = {0};
    
    SECTOR = 0;
    BLOCK = 0;
    BLOCK_NUM = (SECTOR * 4) + BLOCK; 
    
    
    //////��ȡ��һ��block������    
    result = Mifare_Auth( KEY_A_AUTH, 0, KEY_A[0], PICC_A.UID );    //M1��֤
    if( result != FM175XX_SUCCESS )
    {
        printf( "-> AUTH ERROR!\r\n" );					
        return;
    }    
    printf( "-> AUTH SUCCESS SECTOR = %02X \r\n", 0 );
    result = Mifare_Blockread( 0, BLOCK_DATA );
    if( result != FM175XX_SUCCESS )
    {
        printf("-> READ BLOCK0 ERROR!\r\n");		
        return;
    }
    printf( "-> READ BLOCK %02X = ", 0 );  
    printf_array(BLOCK_DATA,16);
    printf( "\r\n" ); 
    
    
    //////д16�ֽ����ݵ���4��block���ڵ�1������ 
//    result = Mifare_Auth( KEY_A_AUTH, 1, KEY_A[0], PICC_A.UID );    //M1��֤
//    if( result != FM175XX_SUCCESS )
//    {
//        printf( "-> AUTH ERROR!\r\n" );					
//        return;
//    }
//    memcpy(block_buff,"\x11\x22\x33\x44\x55\x66\x77\x88\x11\x22\x33\x44\x55\x66\x77\x88",16); //���ô�д���16���ֽ�����
//    
//    result = Mifare_Blockwrite(0x04,block_buff);// ���ַ0x04������1����0��д�����
//    if(result != FM175XX_SUCCESS)
//    {
//        printf("-> Block [4] Write error.\r\n");
//        return;	
//    }	
//    printf("-> Block [4] Write OK.\r\n");

//    result = Mifare_Blockread(0x04,block_buff);//���ַ0x04������1����0���������
//    if(result != FM175XX_SUCCESS)
//    {
//        printf("-> Block [4] Read error.\r\n");
//        return;	
//    }	
//    printf("-> Block [4] Read Data = ");
//    printf_array(block_buff,16);
//    printf("\r\n");    
    
    
    //////��ȡ16��������64 block��������
//    for( i = 0; i < 16; i++ )
//    {
//        SECTOR = i;
//        //M1��֤
//        result = Mifare_Auth( KEY_A_AUTH, SECTOR, KEY_A[SECTOR], PICC_A.UID );
//        if( result != FM175XX_SUCCESS )
//        {
//            printf( "-> AUTH ERROR!\r\n" );					
//            return;
//        }
//        printf( "-> AUTH SUCCESS SECTOR = %02X \r\n", i );

//        //������
//        for( j = 0; j < 4; j++ )
//        {
//            BLOCK = j;
//            BLOCK_NUM = (SECTOR * 4) + BLOCK;
//            result = Mifare_Blockread( BLOCK_NUM, BLOCK_DATA );
//            if( result != FM175XX_SUCCESS )
//            {
//                printf("-> READ BLOCK0 ERROR!\r\n");		
//                return;
//            }
//            printf( "-> READ BLOCK %02X = ", BLOCK_NUM );  for( k=0; k<16; k++ ) { printf( "%02X", BLOCK_DATA[k]); }  printf( "\r\n" );        
//        }   
//    }
    
    printf("Finish to Read and write M1.\r\n" );
}

void Ntag_App( void )
{
    unsigned char result;
    unsigned char i;

    //������
    Page = 0x00;
    result = Ntag_Read( Page, Page_data );
    if( result != FM175XX_SUCCESS )
    {
        printf("-> READ Page0 ERROR!\r\n");		
        return;
    }
    printf( "-> READ Page0 = " );  for( i=0; i<16; i++ ) { printf( "%02X", Page_data[i]); }  printf( "\r\n" ); 

    //д���� 
    Page = 0x10;
    memcpy( Page_data, "\x11\x22\x33\x44", 4 );		
    result = Ntag_Write( Page, Page_data );
    if( result != FM175XX_SUCCESS )
    {
        printf( "-> WRITE Page7 ERROR!\r\n" );		
        return;
    }
    printf( "-> WRITE Page7 SUCCESS!\r\n" );

    //������
    result = Ntag_Read( Page, Page_data );
    if( result != FM175XX_SUCCESS )
    {
        printf("-> READ Page7 ERROR!\r\n");		
        return;
    }
    printf( "-> READ Page7 = " );  for( i=0; i<16; i++ ) { printf( "%02X", Page_data[i]); }  printf( "\r\n" ); 

}


/***************************************************************
//�������ƣ�Check_TypeA_Remove_Status
//�������ܣ�ͨ�����ͼ쿨���0x26����⿨Ƭ�Ƿ��ƿ�
//��ڲ�����last_acquired_uid:�ϴζ����ɹ���UID   picc_a:��Ƭ�Ĳ���
//���ڲ�����result���ɹ���FM176XX_SUCCESS��ʧ�ܣ�����ʧ�ܵķ���ֵ
***************************************************************/
unsigned char Check_TypeA_Remove_Status(struct picc_a_struct *picc_a)
{
    unsigned char result;
    
	SetCW(DISABLE);;   //�ر�TX1��TX2���
	Delay_ms(10);
    FM175xx_Initial_ReaderA();;
	SetCW(ENABLE);  
	Delay_ms(10);        
	result = ReaderA_CardActivate();

	if(result != FM175XX_SUCCESS)
	{                              
		printf("\r\n>> The PICC is removed: fail to activate.\r\n");			
	}    
    return result;
}



//TYPEA��Ƭ����
void Type_A_App(void)
{
    unsigned char result;
    unsigned char i;
  
    FM175xx_HardReset();    
    FM175xx_Initial_ReaderA();  //��ʼ��    
    SetCW( CW_ENABLE );     //���ز�    
    result = ReaderA_CardActivate();//���Ƭ
    
    if ( result != FM175XX_SUCCESS )
    {
        SetCW( CW_DISABLE );
        return;
    }
    
    LED_ON;
    
    printf( "------CardActivate SUCCESS------\r\n" );
    printf( "-> ATQA = %02X%02X \r\n", PICC_A.ATQA[0], PICC_A.ATQA[1] );
    printf( "-> UID = " );
    for ( i=0; i<4*PICC_A.CASCADE_LEVEL; i++ )
        printf( "%02X", PICC_A.UID[i] );
    printf( "\r\n" );
    printf( "-> SAK = %02X \r\n", PICC_A.SAK[0] );
    
    if( PICC_A.SAK[0] == 0x08 )     //Mifare
    {
        Mifare_App();
    }
    if( PICC_A.SAK[0] == 0x04 )     //Ntag  SAK1= 0x04 SAK2=0x00
    {
        Ntag_App();
    }
        
    SetCW( CW_DISABLE );
    Delay_ms( 10 );
    SetCW( CW_ENABLE );     //���ز� 
    if(Check_TypeA_Remove_Status(&PICC_A) == FM175XX_SUCCESS)
    {
        do
        { 
            result = Check_TypeA_Remove_Status(&PICC_A);
            if(result != FM175XX_SUCCESS) 
            {       
                printf("\r\n>> Type A PICC is removed. \r\n"); 
                printf("----------------------------------------------------------\r\n");             
                printf("\r\n");              
                break;	
            }
        }
        while(1);    
    }
    //�ر��ز�
    LED_OFF;
    SetCW( CW_DISABLE );
    return;
}






