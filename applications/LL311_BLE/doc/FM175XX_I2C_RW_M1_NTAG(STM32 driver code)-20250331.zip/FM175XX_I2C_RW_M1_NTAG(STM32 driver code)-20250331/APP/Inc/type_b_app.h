#ifndef TYPE_B_APP_H
#define TYPE_B_APP_H


unsigned char TYPE_B_APP(void);

#endif

