#ifndef TYPE_A_APP_H
#define TYPE_A_APP_H


void Type_A_App(void);


#endif

