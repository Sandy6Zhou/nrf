#include "DEVICE_CFG.h"
#include "FM175xx.h"
#include "FM175xx_Reg.h"
#include "ReaderApi.h"
#include <string.h>
#include "Mifare.h"

unsigned char SECTOR,BLOCK,BLOCK_NUM;
unsigned char BLOCK_DATA[16];

unsigned char KEY_A[16][6] =
{
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //0
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //1
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //2
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //3
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //4
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //5
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //6
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //7
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //8
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //9
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //10
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //11
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //12
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //13
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //14
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF}     //15
};

unsigned char KEY_B[16][6]=
{
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //0
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //1
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //2
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //3
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //4
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //5
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //6
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //7
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //8
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //9
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //10
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //11
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //12
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //13
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF},    //14
    {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF}     //15
};						

/*****************************************************************************************/
/*���ƣ�Mifare_Auth																		 */
/*���ܣ�Mifare_Auth��Ƭ��֤																 */
/*���룺mode����֤ģʽ��0��key A��֤��1��key B��֤����sector����֤�������ţ�0~15��		 */
/*		*mifare_key��6�ֽ���֤��Կ���飻*card_uid��4�ֽڿ�ƬUID����						 */
/*���:																					 */
/*		OK    :��֤�ɹ�																	 */
/*		ERROR :��֤ʧ��																	 */
/*****************************************************************************************/
unsigned char Mifare_Auth( unsigned char mode, unsigned char sector, unsigned char *mifare_key, unsigned char *card_uid )
{
    unsigned char result,reg_data;
    unsigned char outbuf[12],inbuf[1];
    command_struct command_status;

    command_status.SendCRCEnable = SET;
    command_status.ReceiveCRCEnable = SET;   
    command_status.pSendBuf = outbuf;
    command_status.pReceiveBuf = inbuf;
    if( mode == KEY_A_AUTH )
        command_status.pSendBuf[0] = 0x60;          //60 kayA��ָ֤��
    if( mode == KEY_B_AUTH )
        command_status.pSendBuf[0] = 0x61;          //61 keyB��ָ֤��
    
    command_status.pSendBuf[1] = sector * 4;        //��֤�����Ŀ�0��ַ
    command_status.pSendBuf[2] = mifare_key[0];
    command_status.pSendBuf[3] = mifare_key[1];
    command_status.pSendBuf[4] = mifare_key[2];
    command_status.pSendBuf[5] = mifare_key[3];
    command_status.pSendBuf[6] = mifare_key[4];
    command_status.pSendBuf[7] = mifare_key[5];
    command_status.pSendBuf[8] = card_uid[0];
    command_status.pSendBuf[9] = card_uid[1];
    command_status.pSendBuf[10] = card_uid[2];
    command_status.pSendBuf[11] = card_uid[3];
    command_status.Timeout = 10;	
    command_status.nBytesToSend = 12;
    command_status.nBitsToSend = 0;
    command_status.nBitsToReceive = 0;
    command_status.nBytesToReceive = 0;
    command_status.Cmd = CMD_AUTHENT;
    result = Command_Execute( &command_status );
    if( result == FM175XX_SUCCESS )
    {
        GetReg( JREG_STATUS2, &reg_data );
        if( reg_data & 0x08 )//�жϼ��ܱ�־λ��ȷ����֤���
            return FM175XX_SUCCESS;
        else
            return FM175XX_AUTH_ERR;
    }
    return FM175XX_AUTH_ERR;
}

/*****************************************************************************************/
/*���ƣ�Mifare_Blockread																 */
/*���ܣ�Mifare_Blockread��Ƭ�������													 */
/*���룺block����ţ�0x00~0x3F��                        								 */
/*���:	data_buff��16�ֽڶ�����������													 */
/*****************************************************************************************/
unsigned char Mifare_Blockread( unsigned char block, unsigned char *data_buff )
{	
    unsigned char result;
    unsigned char outbuf[2],inbuf[16];
    command_struct command_status;

    command_status.SendCRCEnable = SET;
    command_status.ReceiveCRCEnable = SET;    
    command_status.pSendBuf = outbuf;
    command_status.pReceiveBuf = inbuf;	
    command_status.pSendBuf[0] = 0x30;      //30 ����ָ��
    command_status.pSendBuf[1] = block;     //���ַ
    command_status.nBytesToSend = 2;
    command_status.nBitsToSend = 0;
    command_status.nBitsToReceive = 0;
    command_status.nBytesToReceive = 16;
    command_status.Timeout = 10;
    command_status.Cmd = CMD_TRANSCEIVE;
    result = Command_Execute( &command_status );
    if ( (result != FM175XX_SUCCESS )||(command_status.nBytesReceived != 16) ) 
        return FM175XX_COMM_ERR;
    memcpy( data_buff, command_status.pReceiveBuf, 16 );
    return FM175XX_SUCCESS;
}

/*****************************************************************************************/
/*���ƣ�mifare_blockwrite																 */
/*���ܣ�Mifare��Ƭд�����																 */
/*���룺block����ţ�0x00~0x3F����data_buff��16�ֽ�д����������							 */
/*���:																					 */
/*****************************************************************************************/
unsigned char Mifare_Blockwrite( unsigned char block, unsigned char *data_buff )
{	
	unsigned char outbuf[16],inbuf[1];
	command_struct command_status;

	command_status.SendCRCEnable = SET;
	command_status.ReceiveCRCEnable = RESET;    
	command_status.pSendBuf = outbuf;
	command_status.pReceiveBuf = inbuf;	
	command_status.pSendBuf[0] = 0xA0;      //A0 д��ָ��
	command_status.pSendBuf[1] = block;     //���ַ

	command_status.nBytesToSend = 2;
	command_status.nBitsToSend = 0;
	command_status.nBitsToReceive = 0;
	command_status.nBytesToReceive = 1;
	command_status.Timeout = 10;
    command_status.Cmd = CMD_TRANSCEIVE;
	Command_Execute( &command_status );
	if( (command_status.nBitsReceived != 4) || ((command_status.pReceiveBuf[0]&0x0F)!=0x0A) )       //���δ���յ�0x0A����ʾ��ACK
        return FM175XX_COMM_ERR;
    
	SetTimeOut(10);
	memcpy( command_status.pSendBuf, data_buff, 16 );
	command_status.nBytesToSend = 16;
	command_status.nBytesToReceive = 1;
	command_status.Cmd = CMD_TRANSCEIVE;
	Command_Execute( &command_status );
	if( (command_status.nBitsReceived != 4) || ((command_status.pReceiveBuf[0]&0x0F)!=0x0A) )       //���δ���յ�0x0A����ʾ��ACK
        return FM175XX_COMM_ERR;
	return FM175XX_SUCCESS;
}
