#include "DEVICE_CFG.h"
#include "FM175xx.h"
#include "FM175xx_Reg.h"
#include "ReaderApi.h"
#include <string.h>
#include "NTag.h"

unsigned char Page;
unsigned char Page_data[16];

//********************************************************
//�������ƣ�Ntag_Read( uint8_t page_addr, uint8_t *data_buff )
//�������ܣ���ȡ���ݿ�
//��    ����page_addr:���ַ   data_buff:��ȡ�ķ���ֵ 16 byte / 4bit NAK
//********************************************************
unsigned char Ntag_Read( unsigned char page_addr, unsigned char *data_buff )
{
	unsigned char result;
	unsigned char outbuf[2],inbuf[16];
	command_struct command_status;
    
    command_status.SendCRCEnable = SET;   
    command_status.ReceiveCRCEnable = SET; 
	command_status.pSendBuf = outbuf;
	command_status.pReceiveBuf = inbuf;
	command_status.pSendBuf[0] = 0x30;              //30 ����ָ��
	command_status.pSendBuf[1] = page_addr;         //���ַ
    command_status.nBytesToSend = 2;
	command_status.nBitsToSend = 0;
    command_status.nBitsToReceive = 0;
	command_status.nBytesToReceive = 16;
	command_status.Timeout = 5;                     
	command_status.Cmd = CMD_TRANSCEIVE;
	result = Command_Execute( &command_status );
	if( (result != FM175XX_SUCCESS ) || (command_status.nBytesReceived != 16) ) //���յ������ݳ���Ϊ16
		return FM175XX_COMM_ERR;
	memcpy( data_buff, command_status.pReceiveBuf, 16 );
	return FM175XX_SUCCESS;
}

//********************************************************
//�������ƣ�Ntag_Write( uint8_t page_addr, uint8_t *data_buff )
//�������ܣ���ȡ���ݿ�
//��    ����page_addr:���ַ   data_buff:д������ݣ�4 byte
//********************************************************
unsigned char Ntag_Write( unsigned char page_addr, unsigned char *data_buff )
{
	unsigned char outbuf[6],inbuf[1];
	command_struct command_status;
    
    command_status.SendCRCEnable = SET;
    command_status.ReceiveCRCEnable = RESET;
	command_status.pSendBuf = outbuf;
	command_status.pReceiveBuf = inbuf;
	command_status.pSendBuf[0] = 0xA2;              //A2 д��ָ��
	command_status.pSendBuf[1] = page_addr;         //���ַ
    command_status.pSendBuf[2] = data_buff[0];      
    command_status.pSendBuf[3] = data_buff[1];         
    command_status.pSendBuf[4] = data_buff[2];        
    command_status.pSendBuf[5] = data_buff[3];
    command_status.nBytesToSend = 6;    
	command_status.nBitsToSend = 0;
    command_status.nBitsToReceive = 0;
	command_status.nBytesToReceive = 1;
	command_status.Timeout = 10;                     
	command_status.Cmd = CMD_TRANSCEIVE;
	Command_Execute( &command_status );
	if( (command_status.nBitsReceived != 4)||((command_status.pReceiveBuf[0]&0x0F)!=0x0A) ) //���δ���յ�0x0A����ʾ��ACK
		return FM175XX_COMM_ERR;
	return FM175XX_SUCCESS;
}
