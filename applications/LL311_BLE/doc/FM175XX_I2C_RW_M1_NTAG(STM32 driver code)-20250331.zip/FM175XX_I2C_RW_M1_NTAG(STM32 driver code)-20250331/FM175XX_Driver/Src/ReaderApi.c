#include "DEVICE_CFG.h"
#include "FM175xx.h"
#include "FM175xx_Reg.h"
#include "ReaderApi.h"
#include <string.h>
#include <stdio.h>

struct picc_a_struct PICC_A; 

//****************************************************************************************
//�������ƣ�void SetSendCRC( uint8_t mode )
//�������ܣ�����CRC �� �ر�
//****************************************************************************************
void SetSendCRC( unsigned char mode )
{
    if( mode )
        ModifyReg( JREG_TXMODE, JBIT_TXCRCEN, SET );
    else
        ModifyReg( JREG_TXMODE, JBIT_TXCRCEN, RESET );
    return;
}

//****************************************************************************************
//�������ƣ�void SetReceiveCRC( uint8_t mode )
//�������ܣ�����CRC �� �ر�
//****************************************************************************************
void SetReceiveCRC( unsigned char mode )
{
    if( mode )
        ModifyReg( JREG_RXMODE, JBIT_RXCRCEN, SET );
    else
        ModifyReg( JREG_RXMODE, JBIT_RXCRCEN, RESET );
    return;
}

//****************************************************************************************
//�������ƣ�uint8_t SetTimeOut(uint32_t microseconds)
//�������ܣ����ó�ʱ 0000h~9AA8h
//prescalerԤ��Ƶ��12bit 4095��timereload����ֵ16bit 65535
//timer = ( timerload * ( prescale*2+1 )   +1 )/13560
//timer_max = ( 65536 * ( 4095*2+1 )   +1 )/13560 = 39592ms
//timereload =  ( time*13560 - 1 ) / ( prescale*2+1 )
//****************************************************************************************
void SetTimeOut( unsigned int microseconds )
{
    unsigned long timereload;
    unsigned int prescaler;

    if( microseconds == 0 )
        microseconds = 1;   //ʱ�䲻��Ϊ0
        
    prescaler = 0;
    timereload = 0;
    while( prescaler < 0xFFF )
    {
        timereload = ( ( microseconds*(long)13560 )-1 )/( prescaler*2+1 );
        if( timereload < 0xFFFF )
            break;
        prescaler++;
    }
    timereload = timereload & 0xFFFF; 
    SetReg( JREG_TMODE, JBIT_TAUTO | ((prescaler >> 8) & 0x0F) );   //JBIT_TAUTO�򿪼�ʱ��  TX�����Զ�������ʱ   TPrescaler_Hi ��4bit
    SetReg( JREG_TPRESCALER, prescaler & 0xFF );                    //TPrescaler_Lo ��8bit 				
    SetReg( JREG_TRELOADHI, timereload >> 8 );                      //TReloadVal_Hi
    SetReg( JREG_TRELOADLO, timereload & 0xFF );                    //TReloadVal_Lo
    return;
}

//****************************************************************************************
//��������Command_Execute
//��  ����
//      unsigned char* sendbuf:�������ݻ�����	unsigned char sendlen:�������ݳ���
//      unsigned char* recvbuf:�������ݻ�����	unsigned char* recvlen:���յ������ݳ���
//****************************************************************************************
unsigned char Command_Execute( command_struct *comm_status )
{
    unsigned char reg_data,send_length,receive_length,send_finish;
    unsigned char irq;
    unsigned char result;
    
    send_length = comm_status->nBytesToSend;        //Length of bytes to be sent
    receive_length = 0;
    send_finish = 0;
    comm_status->nBitsReceived = 0;
    comm_status->nBytesReceived = 0;
    comm_status->CollPos = 0;
    comm_status->Error = 0;

    SetReg( JREG_COMMAND, CMD_IDLE );               //Command = Idle
    SetReg( JREG_FIFOLEVEL, JBIT_FLUSHFIFO );       //Flush FIFO
    SetReg( JREG_COMMIRQ, 0x7F );                   //COMMIRQ, clear all IRQ0 flags
    SetReg( JREG_DIVIRQ, 0x7F );                    //DIVIRQ, clear all IRQ1 flags	
    SetReg( JREG_COMMIEN, 0x80 );                   //Disable COMMIRQ to be propagated to IRQ pin    
    SetReg( JREG_DIVIEN, 0x00 );                    //Disable DIVIRQ to be propagated to IRQ pin    	
    SetReg( JREG_WATERLEVEL, 0x20 );                //WaterLevel = 32bytes

    SetSendCRC( comm_status->SendCRCEnable );       //TX CRC
    SetReceiveCRC( comm_status->ReceiveCRCEnable ); //RX CRC
    SetTimeOut( comm_status->Timeout );             //Config Timer

    if( comm_status->Cmd == CMD_AUTHENT )
    {	
        Write_FIFO( send_length, comm_status->pSendBuf );                   //Write FIFO
        send_length = 0; 
        SetReg( JREG_COMMAND, comm_status->Cmd);                                //Authent        
        SetReg( JREG_BITFRAMING, JBIT_STARTSEND | comm_status->nBitsToSend);    //Start Send 	
    }
            
    if( comm_status->Cmd == CMD_TRANSCEIVE )                                    //REQA WUPA  7bit
    {
        SetReg( JREG_COMMAND, comm_status->Cmd );
        SetReg( JREG_BITFRAMING, ( comm_status->nBitsToReceive << 4 ) | comm_status->nBitsToSend ); //Config BITFRAMING  ����ͻ			
    }
    
    while(1)
    {                 
        GetReg( JREG_COMMIRQ, &irq );                                       //��ѯ�жϼĴ���
        //printf( " %02X", irq );
        
        if( irq & JBIT_TIMERI )                                             //TimerIRq = 1  ��ʱ
        {
            SetReg( JREG_COMMIRQ, JBIT_TIMERI );                            //Clear COMMIRQ JBIT_TIMERI	
            result = FM175XX_TIMER_ERR;		
            break;
        }
        
        if( irq & JBIT_ERRI )                                               //ErrIRq = 1    ����
        {			
            GetReg( JREG_ERROR, &reg_data );
            comm_status->Error = reg_data;
            //printf( "  reg_data = %02X ", reg_data );
            if( comm_status->Error & JBIT_COLLERR )                         //JBIT_COLLERR 
            {
                GetReg( JREG_COLL, &reg_data );	
                comm_status->CollPos = reg_data & 0x1F;                     //Get Collide position [5,0]
                result = FM175XX_COLL_ERR;
                break;	
            }
            result = FM175XX_COMM_ERR;                                      //ProtocolErr ParityErr CRCErr CollErr BuffreOvfl RFU TempErr WrErr			
            SetReg( JREG_COMMIRQ, JBIT_ERRI );                              //Clear COMMIRQ JBIT_ERRI			
            break;	
        }

        // =WaterLevel LoAlterIRq/HiAlterIRq;   < WaterLevel LoAlterIRq;   > WaterLevel HiAlterIRq
        if( irq & JBIT_LOALERTI )                                           //LoAlterIRq = 1  ��FIFO  LoAlet = FIFOLength <= WaterLevel
        {
            if( send_length > 0 )
            {
                if( send_length > 32 )
                {			
                    Write_FIFO( 32, comm_status->pSendBuf );            //Write 32 bytes to FIFO	
                    comm_status->pSendBuf = comm_status->pSendBuf + 32;
                    send_length = send_length - 32;
                }
                else
                {
                    Write_FIFO( send_length, comm_status->pSendBuf );	//Write FIFO						
                    send_length = 0;						
                }					
                ModifyReg( JREG_BITFRAMING, JBIT_STARTSEND, SET );          //STARTSEND
            }
            SetReg( JREG_COMMIRQ, JBIT_LOALERTI );                          //Clear COMMIRQ JBIT_LOALERTI
        }

        if( irq & JBIT_HIALERTI )                                           //HiAlterIRq = 1  ��FIFO  HiAlter = (64 - FIFOLength) <= WaterLevel
        {
            if( send_finish == 1 )                                          //ȷ�Ϸ�����ϣ����жϣ��ȶ�32byte����RX�жϴ�����û��RX�жϣ��ȱ����жϡ�
            {
                Read_FIFO( 32, comm_status->pReceiveBuf + comm_status->nBytesReceived );
                comm_status->nBytesReceived = comm_status->nBytesReceived + 32;
            }
            SetReg( JREG_COMMIRQ, JBIT_HIALERTI );                          //Clear COMMIRQ JBIT_HIALERTI
        }

        if( (irq & JBIT_IDLEI) && (comm_status->Cmd == CMD_AUTHENT))        //IdelIRq = 1  ����
        {
            SetReg( JREG_COMMIRQ, JBIT_IDLEI );                             //Clear COMMIRQ JBIT_IDLEI			
            result = FM175XX_SUCCESS;
            break;	
        }				

        if( (irq & JBIT_RXI) &&  (comm_status->Cmd == CMD_TRANSCEIVE)  )    //RxIRq = 1  ����EOF
        {                                                                   
            GetReg( JREG_CONTROL, &reg_data );
            comm_status->nBitsReceived = reg_data & 0x07;                   //Get length of bits received   [2,0]			
            GetReg( JREG_FIFOLEVEL, &reg_data );                           
            receive_length = reg_data & 0x7F;                               //Get length of bytes received	
            
            Read_FIFO( receive_length, comm_status->pReceiveBuf + comm_status->nBytesReceived );    //Read FIFO
            comm_status->nBytesReceived = comm_status->nBytesReceived + receive_length;                 //update length of bytes received
                            
            if( (comm_status->nBytesToReceive != comm_status->nBytesReceived) && (comm_status->nBytesToReceive != 0) )
            {
                result = FM175XX_LENGTH_ERR;                                //���յ������ݳ��ȴ���
                break;
            }	
            SetReg( JREG_COMMIRQ, JBIT_RXI );                               //Clear COMMIRQ JBIT_RXI			
            result = FM175XX_SUCCESS;					
            break;
        }

        if( irq & JBIT_TXI )                                                //TxIRq = 1
        {
            SetReg( JREG_COMMIRQ, JBIT_TXI );                               //Clear COMMIRQ JBIT_TXI	
            if( comm_status->Cmd == CMD_TRANSCEIVE )
                send_finish = 1;                                            //�������
        }
    }
    ModifyReg( JREG_BITFRAMING, JBIT_STARTSEND, RESET );                    //CLR Start Send	
    SetReg( JREG_COMMAND, CMD_IDLE );                                       //IDLE 
    return result;

}

//****************************************************************************************
//�������ƣ�void SetCW( uint8_t mode )
//�������ܣ��ز�����
//****************************************************************************************
void SetCW( unsigned char mode )
{
    if ( mode == CW_DISABLE )
    {
        ModifyReg( JREG_TXCONTROL, JBIT_TX1RFEN | JBIT_TX2RFEN, RESET );
    }
    if ( mode == CW1_ENABLE )
    {
        ModifyReg( JREG_TXCONTROL, JBIT_TX1RFEN, SET );
        ModifyReg( JREG_TXCONTROL, JBIT_TX2RFEN, RESET );
    }
    if ( mode == CW2_ENABLE )
    {
        ModifyReg( JREG_TXCONTROL, JBIT_TX1RFEN, RESET );
        ModifyReg( JREG_TXCONTROL, JBIT_TX2RFEN, SET );
    }
    if ( mode == CW_ENABLE )
    {
        ModifyReg( JREG_TXCONTROL, JBIT_TX1RFEN | JBIT_TX2RFEN, SET );
    }
    mDelay( 5 );      //M1��1ms CPU��/����֤5ms
}

//****************************************************************************************
//�������ƣ�FM175xx_Initial_ReaderA
//�������ܣ�ISO14443AЭ���ʼ��
//****************************************************************************************
void FM175xx_Initial_ReaderA( void )
{	
	SetReg( JREG_TXMODE, 0x00 );                                    //TxCRCEnable = 0; TxSpeed = 106kbps; InvMode = 0; TxFraming = ISO14443A
	SetReg( JREG_RXMODE, JBIT_RXNOERR );	                        //RxCRCEnable = 0; RxSpeed = 106kbps; RxNoError = 1; RxMultiple = 0; RxFraming = ISO14443A
	ModifyReg( JREG_TXAUTO, JBIT_FORCE100ASK, SET );                //Force 100ASK = 1
    SetReg( JREG_MODWIDTH, MODWIDTH_106 );                          //MODWIDTH = 106kbps ���յ��ƿ���
    SetReg( JREG_CONTROL, JBIT_INITIATOR );                         //Initiator = 1 reader
    
	SetReg( JREG_GSN, 0xF1 );                                       //Config[7:4] GSN;�޵���N���� Config[3:0] ModGSN����N���� 	
	SetReg( JREG_CWGSP, 0x3F );                                     //Config[5:0] GSP;�޵���P����
    SetReg(JREG_MODGSP,0x01);
    
	SetReg( JREG_RFCFG, RXGAIN_A << 4 ) ;                           //Config[6:4] RxGain ��������
	SetReg( JREG_RXTRESHOLD, 0x84 );                                //Config[7:4] MinLevel;������ֵ Config CollLevel
    ModifyReg( JREG_STATUS2, JBIT_CRYPTO1ON, RESET );               //�����֤��־�����M1��	   
    	
	return;
}

//****************************************************************************************
//�������ƣ�ReaderA_Wakeup
//�������ܣ�ISO14443 WUPA 52   halt - wupa  
//****************************************************************************************
unsigned char ReaderA_Wakeup( void )
{
	unsigned char result;
	unsigned char outbuf[1],inbuf[2];
    command_struct command_status;
    
	command_status.SendCRCEnable = RESET;
    command_status.ReceiveCRCEnable = RESET; 
	command_status.pSendBuf = outbuf;
	command_status.pReceiveBuf = inbuf;	
	command_status.pSendBuf[0] = RF_CMD_WUPA;   
	command_status.nBytesToSend = 1;
	command_status.nBitsToSend = 7;
	command_status.nBitsToReceive = 0;
	command_status.nBytesToReceive = 2;
	command_status.Timeout = 1;
	command_status.Cmd = CMD_TRANSCEIVE;
	result = Command_Execute( &command_status );
	if( (result == FM175XX_SUCCESS) && (command_status.nBytesReceived == 2) )
	{
		memcpy( PICC_A.ATQA, command_status.pReceiveBuf, 2 );		
	}
	else
		result =  FM175XX_COMM_ERR;
	return result;
}

//****************************************************************************************
//�������ƣ�ReaderA_Request
//�������ܣ�ISO14443 REQA 26  
//****************************************************************************************
unsigned char ReaderA_Request( void )
{
	unsigned char result;
	unsigned char outbuf[1],inbuf[2];
    command_struct command_status;
    
	command_status.SendCRCEnable = RESET;
    command_status.ReceiveCRCEnable = RESET; 
	command_status.pSendBuf = outbuf;
	command_status.pReceiveBuf = inbuf;
	command_status.pSendBuf[0] = RF_CMD_REQA;
    command_status.nBytesToSend = 1;
	command_status.nBitsToSend = 7;    
	command_status.nBitsToReceive = 0;
	command_status.nBytesToReceive = 2;
	command_status.Timeout = 1;
	command_status.Cmd = CMD_TRANSCEIVE;
	result = Command_Execute( &command_status );
	if( (result == FM175XX_SUCCESS) && (command_status.nBytesReceived == 2) )
	{
		memcpy( PICC_A.ATQA, command_status.pReceiveBuf, 2 );		
	}
	else
		result =  FM175XX_COMM_ERR;
	return result;
}

//****************************************************************************************
//�������ƣ�ReaderA_AntiColl
//�������ܣ�ISO14443����ײ   ����ͻ�ȼ�����0��1��2
//��    ����cascade_level   
//****************************************************************************************
unsigned char ReaderA_AntiColl( unsigned char cascade_level )
{
	unsigned char result;
	unsigned char outbuf[2],inbuf[5];
    command_struct command_status;
    
    if(cascade_level > 2)
		return FM175XX_PARAM_ERR;
        
	command_status.SendCRCEnable = RESET;
    command_status.ReceiveCRCEnable = RESET;    
	command_status.pSendBuf = outbuf;
	command_status.pReceiveBuf = inbuf;	
	command_status.pSendBuf[0] = RF_CMD_ANTICOL[cascade_level];     //����ͻ�ȼ�
	command_status.pSendBuf[1] = 0x20;
    command_status.nBytesToSend = 2;
    command_status.nBitsToSend = 0;						
	command_status.nBitsToReceive = 0;
	command_status.nBytesToReceive = 5;
	command_status.Timeout = 1;	
	command_status.Cmd = CMD_TRANSCEIVE;
	result = Command_Execute( &command_status );
	ModifyReg( JREG_COLL, JBIT_VALUESAFTERCOLL, SET );              //���Գ�ͻ
	if( (result == FM175XX_SUCCESS) && (command_status.nBytesReceived == 5) )
	{
		memcpy( PICC_A.UID + (cascade_level*4), command_status.pReceiveBuf, 4 );
		memcpy( PICC_A.BCC + cascade_level, command_status.pReceiveBuf + 4, 1 );
		if( (PICC_A.UID[cascade_level*4] ^  PICC_A.UID[cascade_level*4 + 1] ^ PICC_A.UID[cascade_level*4 + 2]^ PICC_A.UID[cascade_level*4 + 3] ^ PICC_A.BCC[cascade_level]) !=0 )
            result = FM175XX_COMM_ERR;
	}
	return result;
}

//****************************************************************************************
//�������ƣ�ReaderA_Select
//�������ܣ�ISO14443ѡ��    open crc
//��    ����cascade_level �ȼ�  
//****************************************************************************************
unsigned char ReaderA_Select( unsigned char cascade_level )
{
	unsigned char result;
	unsigned char outbuf[7],inbuf[1];
    command_struct command_status;
    
    if(cascade_level > 2)
		return FM175XX_PARAM_ERR;
    
	command_status.SendCRCEnable = SET;
    command_status.ReceiveCRCEnable = SET;   
	command_status.pSendBuf = outbuf;
	command_status.pReceiveBuf = inbuf;	
	*(command_status.pSendBuf+0) = RF_CMD_ANTICOL[cascade_level];   //����ͻ�ȼ�
	*(command_status.pSendBuf+1) = 0x70;   					
	*(command_status.pSendBuf+2) = PICC_A.UID[4*cascade_level];
	*(command_status.pSendBuf+3) = PICC_A.UID[4*cascade_level+1];
	*(command_status.pSendBuf+4) = PICC_A.UID[4*cascade_level+2];
	*(command_status.pSendBuf+5) = PICC_A.UID[4*cascade_level+3];
	*(command_status.pSendBuf+6) = PICC_A.BCC[cascade_level];
    command_status.nBytesToSend = 7;
   	command_status.nBitsToSend = 0;
	command_status.nBitsToReceive = 0;
	command_status.nBytesToReceive = 1;
	command_status.Timeout = 1;
	command_status.Cmd = CMD_TRANSCEIVE;
	result = Command_Execute( &command_status );
	if( (result == FM175XX_SUCCESS) && (command_status.nBytesReceived == 1) )
		PICC_A.SAK[cascade_level] = *(command_status.pReceiveBuf);
	else
		result = FM175XX_COMM_ERR;
	return result;
}

//****************************************************************************************
//�������ƣ�ReaderA_Halt
//�������ܣ�ֹͣ    Halt wakeup
//****************************************************************************************
unsigned char ReaderA_Halt( void )
{
    unsigned char result;
    unsigned char outbuf[2],inbuf[2];
    command_struct command_status;

    command_status.SendCRCEnable = SET;   
    command_status.ReceiveCRCEnable = SET; 
    command_status.pSendBuf = outbuf;
    command_status.pReceiveBuf = inbuf;	
    command_status.pSendBuf[0] = 0x50;
    command_status.pSendBuf[1] = 0x00;
    command_status.nBytesToSend = 2;
    command_status.nBitsToSend = 0;
    command_status.nBitsToReceive = 0;
    command_status.nBytesToReceive = 0;
    command_status.Timeout = 1;	
    command_status.Cmd = CMD_TRANSCEIVE;	
    result = Command_Execute( &command_status );
    if( result == FM175XX_TIMER_ERR )
        result = FM175XX_SUCCESS;
    return result;
}

//****************************************************************************************
//�������ƣ�ReaderA_CardActivate
//�������ܣ�ISO14443�����ACTIVE 
//****************************************************************************************
unsigned char ReaderA_CardActivate( void )
{
    unsigned char result, cascade_level;
	
    result = ReaderA_Wakeup();	
    if( result != FM175XX_SUCCESS )
    {	
        return FM175XX_COMM_ERR;
    }
    if( (PICC_A.ATQA[0]&0xC0) == 0x00 )     //1��UID		
        cascade_level = 1;
    if( (PICC_A.ATQA[0]&0xC0) == 0x40 )     //2��UID			
        cascade_level = 2;		
    if( (PICC_A.ATQA[0]&0xC0) == 0x80 )     //3��UID
        cascade_level = 3;				

    for( PICC_A.CASCADE_LEVEL=0; PICC_A.CASCADE_LEVEL<cascade_level; PICC_A.CASCADE_LEVEL++ )
    {
        result = ReaderA_AntiColl( PICC_A.CASCADE_LEVEL );
        if( result != FM175XX_SUCCESS )
            return FM175XX_COMM_ERR;
        result = ReaderA_Select( PICC_A.CASCADE_LEVEL );
        if( result != FM175XX_SUCCESS )
            return FM175XX_COMM_ERR;
    }
    return result;    
}
