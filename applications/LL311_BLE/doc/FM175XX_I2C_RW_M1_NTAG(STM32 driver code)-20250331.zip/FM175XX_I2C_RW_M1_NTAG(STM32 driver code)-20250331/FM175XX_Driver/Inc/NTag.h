#ifndef _NTAG_H_
#define _NTAG_H_

extern unsigned char Page;
extern unsigned char Page_data[16];

extern unsigned char Ntag_Read( unsigned char page_addr, unsigned char *data_buff );
extern unsigned char Ntag_Write( unsigned char page_addr, unsigned char *data_buff );

#endif
