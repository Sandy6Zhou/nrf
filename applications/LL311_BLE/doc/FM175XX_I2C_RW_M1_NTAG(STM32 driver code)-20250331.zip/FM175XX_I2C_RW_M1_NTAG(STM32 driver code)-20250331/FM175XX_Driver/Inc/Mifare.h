#ifndef _MIFARE_H_
#define _MIFARE_H_

#define KEY_A_AUTH 0
#define KEY_B_AUTH 1





extern unsigned char SECTOR,BLOCK,BLOCK_NUM;
extern unsigned char BLOCK_DATA[16];
extern unsigned char KEY_A[16][6];
extern unsigned char KEY_B[16][6];
extern unsigned char Mifare_Auth( unsigned char mode, unsigned char sector, unsigned char *mifare_key, unsigned char *card_uid );
extern unsigned char Mifare_Blockread( unsigned char block, unsigned char *data_buff );
extern unsigned char Mifare_Blockwrite( unsigned char block, unsigned char *data_buff );

#endif
