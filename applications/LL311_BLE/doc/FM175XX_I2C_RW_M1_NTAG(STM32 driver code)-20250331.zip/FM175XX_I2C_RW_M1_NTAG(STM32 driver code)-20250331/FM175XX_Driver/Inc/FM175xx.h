#ifndef _FM175XX_H
#define _FM175XX_H



extern void GetReg( unsigned char reg_addr, unsigned char *reg_data );
extern void SetReg( unsigned char reg_addr, unsigned char reg_data );
extern void ModifyReg( unsigned char reg_addr, unsigned char mask, unsigned char set );
extern void SPI_Read_FIFO( unsigned char reglen, unsigned char* regbuf ); 
extern void SPI_Write_FIFO( unsigned char reglen, unsigned char* regbuf );
extern void FM175xx_HardReset( void );
extern void FM175xx_SoftReset( void );
void Write_FIFO(unsigned char length,unsigned char *fifo_data);
void Read_FIFO(unsigned char length,unsigned char *fifo_data);
void Set_BitMask(unsigned char reg_addr,unsigned char mask);
void Clear_BitMask(unsigned char reg_addr,unsigned char mask);
unsigned char Check_Read_Write_FM175XX_FIFO(void);
    
#endif





