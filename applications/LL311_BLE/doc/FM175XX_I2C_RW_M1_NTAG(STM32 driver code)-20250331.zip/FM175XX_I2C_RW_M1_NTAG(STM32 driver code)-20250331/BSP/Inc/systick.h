#ifndef __SYSTICK_H
#define __SYSTICK_H
#include "stdint.h"
#include <math.h>
#include "stm32f10x.h"

void Delay_ns(uint32_t n);
void Delay_us(uint32_t n);
void Delay_ms(uint32_t n);
void Delay_us(uint32_t n);

#endif /* __SYSTICK_H */
