#ifndef __DEVICE_CFG_H
#define __DEVICE_CFG_H

#include "stm32f10x.h"

#define  UART3_BaudRate      115200

#define USE_I2C_DRV  1


#define PORT_IRQ			GPIOB
#define PIN_IRQ				GPIO_Pin_10			//PB10 IRQ����

#define PORT_NPD			GPIOB
#define PIN_NPD				GPIO_Pin_11			//PB11 NPD����

//FM175xx SPI
#define PORT_SPI            GPIOB
#define PIN_NSS             GPIO_Pin_12			//PB12 NSS���ţ�Pin24��
#define PIN_SCK             GPIO_Pin_13			//PB13 SCK���ţ�Pin29��
#define PIN_MISO            GPIO_Pin_14			//PB14 MISO���ţ�Pin31��
#define PIN_MOSI            GPIO_Pin_15			//PB15 MOSI���ţ�Pin30��


#define PORT_I2C			GPIOB
//#define PIN_SCL				GPIO_Pin_6			//PB6 - SCL
//#define PIN_SDA				GPIO_Pin_7			//PB7 - SDA
#define PIN_SCL				GPIO_Pin_8			//PB8 - SCL
#define PIN_SDA				GPIO_Pin_9			//PB9 - SDA


//LED���ƣ�PB1 ����Ч
#define PORT_LED            GPIOB		   
#define PIN_LED0            GPIO_Pin_1

#define LED_OFF             (PORT_LED->BSRR = PIN_LED0)     //LED0
#define LED_ON              (PORT_LED->BRR = PIN_LED0)      //LED0


extern void RCC_Config( void );
extern void GPIO_Config( void );
extern void mDelay( unsigned int ms );
extern void uDelay( unsigned int us );
void BSP_Init(void);
    
#endif
