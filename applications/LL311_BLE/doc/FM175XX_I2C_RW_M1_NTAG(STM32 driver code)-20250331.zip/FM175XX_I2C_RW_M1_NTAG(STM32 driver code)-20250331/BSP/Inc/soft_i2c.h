#ifndef __SOFT_I2C_H
#define __SOFT_I2C_H

#include "stm32f10x.h"


#define I2C_Address     0x28        //ADR1~ADR2=0
#define I2C_Write	    0x00
#define I2C_Read        0x01
#define I2C_ACK         0
#define I2C_NAK         1

#define SCL_H           GPIO_SetBits(PORT_I2C,PIN_SCL)
#define SCL_L           GPIO_ResetBits(PORT_I2C,PIN_SCL)

#define SDA_H           GPIO_SetBits(PORT_I2C,PIN_SDA)
#define SDA_L           GPIO_ResetBits(PORT_I2C,PIN_SDA)


void I2C_INIT(void);
void I2C_START(void);
void I2C_STOP(void);
void I2C_SEND_BYTE(unsigned char send_data,unsigned char *ack);
void I2C_RECEIVE_BYTE(unsigned char *receive_data,unsigned char ack);


#endif

