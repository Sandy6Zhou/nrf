#ifndef __UART_H
#define	__UART_H

#include "stm32f10x.h"
#include <stdio.h>




extern uint8_t rx_length;
extern uint8_t rx_finish_flag;
extern uint8_t uart_rx_buff[100];

//#define USART1_FOR_PRINTF		1

void USART1_Config(uint32_t BaudRate);
void USART2_Config(uint32_t BaudRate);
void USART3_Config(uint32_t BaudRate);

void UART1SendByte( unsigned char SendData );
void UART2SendByte( unsigned char SendData );
void UART1_Send( unsigned char *SendDataBuff, unsigned int Length );
void Uart_Send_Msg( char *SendDataBuff );
void Uart_Send_Hex( unsigned char *SendDataBuff, unsigned int Length );
void printf_array(unsigned char *buff, unsigned char length);
#endif /* __USART1_H */

