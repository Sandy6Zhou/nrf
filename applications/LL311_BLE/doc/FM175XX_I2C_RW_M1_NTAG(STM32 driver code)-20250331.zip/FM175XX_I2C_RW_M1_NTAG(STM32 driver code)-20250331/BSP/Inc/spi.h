#ifndef __SPI_H
#define __SPI_H

#include "stm32f10x.h"
#include "device_cfg.h"


#define SPI_TIMEOUT_VALUE  200

#define TIMEOUT_ERROR       0xE0


void SPI1_Config(void);
void SPI2_Config(void);
void SPI_Config(void);
uint8_t SPI1_Send_Receive_Byte(uint8_t TxData);
uint8_t SPI2_Send_Receive_Byte(uint8_t TxData);
unsigned char SPIx_ReadWriteByte(unsigned char TxData);

#endif

