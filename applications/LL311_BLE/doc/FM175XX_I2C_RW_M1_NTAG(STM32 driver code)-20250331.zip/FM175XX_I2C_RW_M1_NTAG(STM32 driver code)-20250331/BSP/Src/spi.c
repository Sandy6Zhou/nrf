#include "spi.h"



void SPI1_Config(void)
{
    SPI_InitTypeDef SPI_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_SPI1 | RCC_APB2Periph_AFIO, ENABLE);
	
	/*SPI1 Configuration*/
	// Configure SPI1 SCK(PA5)��MISO(PA6)��MOSI(PA7) as alternate function push-pull 
	GPIO_InitStructure.GPIO_Pin = PIN_SCK | PIN_MISO | PIN_MOSI; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; 
	GPIO_Init(PORT_SPI, &GPIO_InitStructure);  
	//Configure SPI1 NSS (PB6)
	GPIO_InitStructure.GPIO_Pin = PIN_NSS;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_Init(GPIOB, &GPIO_InitStructure);	
        
    /* SPI1 Config: SPI1 Master*/
    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;   
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;

//    SPI_InitStructure.SPI_CPOL = SPI_CPOL_High;   
//    SPI_InitStructure.SPI_CPHA = SPI_CPHA_2Edge;  
    
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16;      //4.5M   
//    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_32;    //2.2M
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_Init(SPI1, &SPI_InitStructure);  
    SPI_Cmd(SPI1, ENABLE);/* Enable SPI1 */
}


void SPI2_Config(void)
{
    SPI_InitTypeDef SPI_InitStructure;	
	GPIO_InitTypeDef GPIO_InitStructure;	
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);     //ʹ��SPI2��ʱ��           
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);	
	
	/*SPI2 IO Configuration*/
	// Configure SPI2 NSS (PB.12)��SCK(PB.13)��MISO(PB.14)��MOSI(PB.15) as alternate function push-pull  
	GPIO_InitStructure.GPIO_Pin = PIN_SCK | PIN_MISO | PIN_MOSI; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; 
	GPIO_Init(PORT_SPI, &GPIO_InitStructure);  

	GPIO_InitStructure.GPIO_Pin = PIN_NSS;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_Init(PORT_SPI, &GPIO_InitStructure);
    
		
    /* SPI2 Config: SPI2 Master*/
    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16;
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_Init(SPI2, &SPI_InitStructure);  
    SPI_Cmd(SPI2, ENABLE);/* Enable SPI2 */
}


void SPI_Config(void)
{
    SPI_InitTypeDef SPI_InitStructure;	
	GPIO_InitTypeDef GPIO_InitStructure;	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB1Periph_SPI2 | RCC_APB2Periph_AFIO, ENABLE);	
	
	/*SPI2 IO Configuration*/
	// Configure SPI2 NSS (PB.12)��SCK(PB.13)��MISO(PB.14)��MOSI(PB.15) as alternate function push-pull  
	GPIO_InitStructure.GPIO_Pin = PIN_SCK | PIN_MISO | PIN_MOSI; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; 
	GPIO_Init(PORT_SPI, &GPIO_InitStructure);  

	GPIO_InitStructure.GPIO_Pin = PIN_NSS;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_Init(PORT_SPI, &GPIO_InitStructure);
	
	
    /* SPI2 Config: SPI2 Master*/
    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_16;
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_Init(SPI2, &SPI_InitStructure);  
    SPI_Cmd(SPI2, ENABLE);/* Enable SPI2 */
}


/*******************************************************************
�������ƣ�SPI1_Send_Receive_Byte(uint8_t TxData)
�������ܣ�SPI1�շ�һ���ֽ�����
��ڲ�����TxData:��Ҫ���͵�����
���ز�����SPI1���յ�������
*******************************************************************/
uint8_t SPI1_Send_Receive_Byte(uint8_t TxData)
{           
	unsigned char timer = 0;    
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET)// �ȴ���������  
    {
        timer++;
        if(timer > SPI_TIMEOUT_VALUE)
            return TIMEOUT_ERROR;
    }
    
    SPI_I2S_SendData(SPI1, TxData);                                 // ͨ������SPI2����һ��byte����
    timer = 0; 
    while (SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET)// �ȴ�������һ��byte  
    {
        timer++;
        if(timer > SPI_TIMEOUT_VALUE)
            return TIMEOUT_ERROR;
    }   
    return SPI_I2S_ReceiveData(SPI1);                               // ����ͨ��SPIx������յ�����          
}


/*******************************************************************
�������ƣ�SPI2_Send_Receive_Byte(uint8_t TxData)
�������ܣ�SPI2�շ�һ���ֽ�����
��ڲ�����TxData:��Ҫ���͵�����
���ز�����SPI2���յ�������
*******************************************************************/
uint8_t SPI2_Send_Receive_Byte(uint8_t TxData)
{           
	unsigned char timer = 0;    
    while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET)// �ȴ���������  
    {
        timer++;
        if(timer > SPI_TIMEOUT_VALUE)
            return TIMEOUT_ERROR;
    }
    
    SPI_I2S_SendData(SPI2, TxData);                                 // ͨ������SPI2����һ��byte����
    timer = 0; 
    while (SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET)// �ȴ�������һ��byte  
    {
        timer++;
        if(timer > SPI_TIMEOUT_VALUE)
            return TIMEOUT_ERROR;
    }   
    return SPI_I2S_ReceiveData(SPI2);                               // ����ͨ��SPIx������յ�����          
}




/*******************************************************************************
* Function Name  : SPIx_ReadWriteByte
* Description    : SPI 
* Input          : None.
* Return         : None.
*******************************************************************************/
unsigned char SPIx_ReadWriteByte(unsigned char TxData)
{		
	unsigned char retry=0;				 	
	while( SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_TXE) == RESET ) //���ָ����SPI��־λ�������:���ͻ���ձ�־λ
	{
		retry++;
		if( retry>200 )return 0;
	}			  
	SPI_I2S_SendData( SPI2, TxData );   //ͨ������SPIx����һ������
	retry=0;

	while( SPI_I2S_GetFlagStatus(SPI2, SPI_I2S_FLAG_RXNE) == RESET ) //���ָ����SPI��־λ�������:���ܻ���ǿձ�־λ
	{
		retry++;
		if( retry>200 )return 0;
	}	  						    
	return SPI_I2S_ReceiveData( SPI2 ); //����ͨ��SPIx������յ�����					    
}
