#include "SysTick.h"

void set_timeout_nsec(uint32_t n)
{
	/* ����ȡ�� */
	uint32_t ticks = ceil(n/14);

	SysTick->CTRL = 0;
	/* set reload value register */
	SysTick->LOAD = (ticks & SysTick_LOAD_RELOAD_Msk) - 1;
	/* set current value register */
	SysTick->VAL = 0;
	/* enable SysTick timer and use internal clock source */
	SysTick->CTRL = SysTick_CTRL_ENABLE_Msk | SysTick_CTRL_CLKSOURCE_Msk;
}

void set_timeout_usec(uint32_t n)
{
	uint32_t ticks = n * (72000000 / 1000000);

	SysTick->CTRL = 0;
	/* set reload value register */
	SysTick->LOAD = (ticks & SysTick_LOAD_RELOAD_Msk) - 1;
	/* set current value register */
	SysTick->VAL = 0;
	/* enable SysTick timer and use internal clock source */
	SysTick->CTRL = SysTick_CTRL_ENABLE_Msk | SysTick_CTRL_CLKSOURCE_Msk;
}

void set_timeout_msec(uint32_t n)
{
	uint32_t ticks = n * (9000000 / 1000);

	SysTick->CTRL = 0;
	/* Set reload value */
	SysTick->LOAD = (ticks & SysTick_LOAD_RELOAD_Msk) - 1;
	/* Reset SysTick counter value */
	SysTick->VAL = 0;
	/* Enable SysTick timer and use external clock source */
    SysTick->CTRL = SysTick_CTRL_ENABLE_Msk;

}

uint8_t is_timeout(void)
{
	if (SysTick->CTRL & SysTick_CTRL_COUNTFLAG_Msk) {
		SysTick->CTRL = 0;
		return 1;
	}
	else {
		return 0;
	}
}

void Delay_ns(uint32_t n)
{
	set_timeout_nsec(n);
	while (!is_timeout());
}

void Delay_us(uint32_t n)
{
	set_timeout_usec(n);
	while (!is_timeout());
}

void Delay_ms(uint32_t n)
{
	set_timeout_msec(n);
	while (!is_timeout());
}

void Delay_sec(uint32_t n)
{
	while (n--)
		Delay_ms(1000);
}
