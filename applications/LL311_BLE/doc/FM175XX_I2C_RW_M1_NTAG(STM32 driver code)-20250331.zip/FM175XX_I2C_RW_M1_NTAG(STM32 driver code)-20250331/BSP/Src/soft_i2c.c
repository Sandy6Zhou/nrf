#include "soft_i2c.h"
#include "device_cfg.h"



GPIO_InitTypeDef   GPIO_InitStructure;


void I2C_INIT(void)
{    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = PIN_SCL ; 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //
    GPIO_Init(PORT_I2C, &GPIO_InitStructure); 

    GPIO_InitStructure.GPIO_Pin = PIN_SDA; 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //
    GPIO_Init(PORT_I2C, &GPIO_InitStructure); 

    SDA_H;//SDA = 1	
    SCL_H;//SCL = 1
}

//void I2C_START(void)
//{
//	uDelay(1);
//	SDA_L;//SDA = 0
//	uDelay(1);
//	SCL_L;//SCL = 0
//	uDelay(1);
//}

//void I2C_STOP(void)
//{	
//	SDA_L;//SDA = 0

//	uDelay(1);
//	SCL_H;//SCL = 1
//	uDelay(1);
//	SDA_H;//SDA = 1
//}

//void I2C_SEND_BYTE(unsigned char send_data,unsigned char *ack)
//{
//	unsigned char i,i2c_data;
//	GPIO_InitStructure.GPIO_Pin = PIN_SDA; 
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //
//	GPIO_Init(PORT_I2C, &GPIO_InitStructure); 
//	i2c_data = send_data;
//	for (i=0;i<8;i++)
//	{
//		if(i2c_data & 0x80)
//				SDA_H;//SDA = 1
//		else
//				SDA_L;//SDA = 0
//		SCL_H;//SCL = 1
//		uDelay(1);
//		SCL_L;//SCL = 0
//		SDA_L;//SDA = 0
//		i2c_data = i2c_data<<1;
//		uDelay(1);
//	}	
//	
//	GPIO_InitStructure.GPIO_Pin = PIN_SDA; 
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //
//	GPIO_Init(PORT_I2C, &GPIO_InitStructure); 
//	SCL_H;//SCL = 1
//	uDelay(1);
//	*ack =  GPIO_ReadInputDataBit(PORT_I2C,PIN_SDA);//����ACK	    
//	SCL_L;//SCL = 0
//	GPIO_InitStructure.GPIO_Pin = PIN_SDA; 
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //
//	GPIO_Init(PORT_I2C, &GPIO_InitStructure);
//	SDA_L;//SDA = 0
//	
//}

//void I2C_RECEIVE_BYTE(unsigned char *receive_data,unsigned char ack)
//{
//	unsigned char i,i2c_data;
//	GPIO_InitStructure.GPIO_Pin = PIN_SDA; 
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //
//	GPIO_Init(PORT_I2C, &GPIO_InitStructure); 
//	i2c_data = 0;
//	for (i=0;i<8;i++)
//	{
//		i2c_data = i2c_data<<1;
//		SCL_H;//SCL = 1
//		uDelay(1);
//		i2c_data |= GPIO_ReadInputDataBit(PORT_I2C,PIN_SDA);			
//		SCL_L;//SCL = 0	
//		uDelay(1);
//	}	
//	*receive_data = i2c_data;
//		
//	if(ack == I2C_ACK)
//		SDA_L;//���ACK
//	else
//		SDA_H;//���NAK
//	
//	GPIO_InitStructure.GPIO_Pin = PIN_SDA; 
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //
//	GPIO_Init(PORT_I2C, &GPIO_InitStructure); 
//		
//	SCL_H;//SCL = 1	
//	uDelay(1);	
//	SCL_L;//SCL = 0	
//}


void I2C_START(void)
{
	uDelay(1);
	GPIO_ResetBits(PORT_I2C,PIN_SDA);//SDA = 0
	uDelay(1);
	GPIO_ResetBits(PORT_I2C,PIN_SCL);//SCL = 0
	uDelay(1);
}

void I2C_STOP(void)
{	
	GPIO_ResetBits(PORT_I2C,PIN_SDA);//SDA = 0
	uDelay(1);
	GPIO_SetBits(PORT_I2C,PIN_SCL);//SCL = 1
	uDelay(1);
	GPIO_SetBits(PORT_I2C,PIN_SDA);//SDA = 1
}

void I2C_SEND_BYTE(unsigned char send_data,unsigned char *ack)
{
	unsigned char i,i2c_data;
	GPIO_InitStructure.GPIO_Pin = PIN_SDA; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //
	GPIO_Init(PORT_I2C, &GPIO_InitStructure); 
	i2c_data = send_data;
	for (i=0;i<8;i++)
	{
		if(i2c_data & 0x80)
				GPIO_SetBits(PORT_I2C,PIN_SDA);//SDA = 1
		else
				GPIO_ResetBits(PORT_I2C,PIN_SDA);//SDA = 0
		GPIO_SetBits(PORT_I2C,PIN_SCL);//SCL = 1
		uDelay(1);
		GPIO_ResetBits(PORT_I2C,PIN_SCL);//SCL = 0
		GPIO_ResetBits(PORT_I2C,PIN_SDA);//SDA = 0
		i2c_data = i2c_data<<1;
		uDelay(1);
	}	
	
	GPIO_InitStructure.GPIO_Pin = PIN_SDA; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //
	GPIO_Init(PORT_I2C, &GPIO_InitStructure); 
	GPIO_SetBits(PORT_I2C,PIN_SCL);//SCL = 1
	uDelay(1);
	*ack =  GPIO_ReadInputDataBit(PORT_I2C,PIN_SDA);//����ACK	
	GPIO_ResetBits(PORT_I2C,PIN_SCL);//SCL = 0
	GPIO_InitStructure.GPIO_Pin = PIN_SDA; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //
	GPIO_Init(PORT_I2C, &GPIO_InitStructure);
	GPIO_ResetBits(PORT_I2C,PIN_SDA);//SDA = 0
	
}

void I2C_RECEIVE_BYTE(unsigned char *receive_data,unsigned char ack)
{
	unsigned char i,i2c_data;
	GPIO_InitStructure.GPIO_Pin = PIN_SDA; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING; //
	GPIO_Init(PORT_I2C, &GPIO_InitStructure); 
	i2c_data = 0;
	for (i=0;i<8;i++)
	{
		i2c_data = i2c_data<<1;
		GPIO_SetBits(PORT_I2C,PIN_SCL);//SCL = 1
		uDelay(1);
		i2c_data |= GPIO_ReadInputDataBit(PORT_I2C,PIN_SDA);			
		GPIO_ResetBits(PORT_I2C,PIN_SCL);//SCL = 0	
		uDelay(1);
	}	
	*receive_data = i2c_data;
		
	if(ack == I2C_ACK)
		GPIO_ResetBits(PORT_I2C,PIN_SDA);//���ACK
	else
		GPIO_SetBits(PORT_I2C,PIN_SDA);//���NAK
	
	GPIO_InitStructure.GPIO_Pin = PIN_SDA; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; //
	GPIO_Init(PORT_I2C, &GPIO_InitStructure); 
		
	GPIO_SetBits(PORT_I2C,PIN_SCL);//SCL = 1	
	uDelay(1);	
	GPIO_ResetBits(PORT_I2C,PIN_SCL);//SCL = 0
	
}


