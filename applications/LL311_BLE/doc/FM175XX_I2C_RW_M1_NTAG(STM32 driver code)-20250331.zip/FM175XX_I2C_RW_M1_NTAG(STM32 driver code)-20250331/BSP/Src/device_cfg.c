/* Includes ------------------------------------------------------------------*/
#include "device_cfg.h"
#include "spi.h"
#include "uart.h"
#include "soft_i2c.h"


/*******************************************************************************
* Function Name  : RCC_Config
* Description    : Configures Main system clocks & power
* Input          : None.
* Return         : None.
*******************************************************************************/
void RCC_Config( void )
{
    u8 status;

    /* RCC system reset */
    RCC_DeInit();

    /* Enable HSE */
    RCC_HSEConfig( RCC_HSE_ON );                //ʹ���ⲿ����ʱ��	   

    /* Wait till HSE is ready */
    status = RCC_WaitForHSEStartUp();       		

    if( status == SUCCESS )				    
    {
        /* Enable Prefetch Buffer */
        FLASH_PrefetchBufferCmd( FLASH_PrefetchBuffer_Enable );
        /* Flash 2 wait state */
        FLASH_SetLatency( FLASH_Latency_2 );

        /* HCLK = SYSCLK */
        RCC_HCLKConfig( RCC_SYSCLK_Div1 ); 
        /* PCLK2 = HCLK */					   
        RCC_PCLK2Config( RCC_HCLK_Div1 );       //APB2 CLK : 72MHz
        /* PCLK1 = HCLK/2 */
        RCC_PCLK1Config( RCC_HCLK_Div2 );       //APB1 CLK :36MHz
        
        /* PLLCLK = 9 * 8MHz= 72 MHz */ 
        //#define HSE_Value    ((u32)8000000) /* Value of the External oscillator in Hz  8MHZ*/	
        //stm32f10x_conf.h����Ҫ������һ���޸ģ��мǣ�����
        
        /* PLLCLK = 8MHz * 9 = 72 MHz */
        RCC_PLLConfig( RCC_PLLSource_HSE_Div1, RCC_PLLMul_9 );  
        
        /* Enable PLL */         
        RCC_PLLCmd( ENABLE );
        
        /* Wait till PLL is ready */ 
        while( RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET ) {} 
        
        /* Select PLL as system clock source */
        RCC_SYSCLKConfig( RCC_SYSCLKSource_PLLCLK );
            
        /* Wait till PLL is used as system clock source */
        while( RCC_GetSYSCLKSource() != 0x08 ) {}		

        //��APB2�µ���Χģ��ʱ��
        RCC_APB1PeriphClockCmd( RCC_APB1Periph_SPI2|RCC_APB1Periph_USART3, ENABLE );
            
        RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD|RCC_APB2Periph_USART1|RCC_APB2Periph_AFIO|RCC_APB2Periph_TIM1, ENABLE );
          
    }
    else    //�ⲿ����û�й���
    { 
        /* If HSE fails to start-up, the application will have wrong clock configuration.
        User can add here some code to deal with this error */    

        /* Go to infinite loop */
        while(1)
        {
        }
    }
}

/*******************************************************************************
* Function Name  : GPIO_CONFIG
* Description    : Configures GPIO
* Input          : None.
* Return         : None.
*******************************************************************************/
void GPIO_Config( void )
{
    GPIO_InitTypeDef GPIO_InitStructure;
    
    //PD2 LED
    GPIO_InitStructure.GPIO_Pin = PIN_LED0;					
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed= GPIO_Speed_10MHz;
    GPIO_Init( PORT_LED, &GPIO_InitStructure );
    
    //PB10 IRQ
    GPIO_InitStructure.GPIO_Pin = PIN_IRQ;  
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;       //GPIO_Mode_IN_FLOATING��������	 GPIO_Mode_IPU���� GPIO_Mode_IPD����
    GPIO_Init( PORT_IRQ, &GPIO_InitStructure );
    
    //PB11 NPD
    GPIO_InitStructure.GPIO_Pin = PIN_NPD;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
  	GPIO_Init( PORT_NPD, &GPIO_InitStructure );
}


void mDelay( unsigned int ms )			//ʵ��1ms
{
	unsigned int i;
	unsigned int j;
	for( j=0;j<ms;j++ )
	{
		for( i=0;i<8100;i++ )
			;
	}
}

void uDelay( unsigned int us )			//ʵ��1us
{
	unsigned int i;
	unsigned int j;
	for( j=0;j<us;j++ )
	{
		for( i=0;i<81;i++ );
	}
}


void BSP_Init(void)
{
	RCC_Config();       //ʱ������
	GPIO_Config();		//GPIO����	
	USART1_Config(115200);	//UART1����
    
    #ifdef	USE_I2C_DRV     
        I2C_INIT();
        printf("Use I2C interface.\r\n");
    #else        
        SPI2_Config();			//����SPI��������
        printf("Use SPI interface.\r\n");
    #endif

    //EXTI_Config();  	//�ⲿ�ж�����     
}



