/* Includes ------------------------------------------------------------------*/
#include <stdio.h> 
#include <string.h>
#include "systick.h"
#include "device_cfg.h"
#include "uart.h"
#include "FM175xx.h"
#include "FM175xx_Reg.h"
#include "type_a_app.h"

 

int main(void)
{	
//    unsigned char i,status;
    unsigned char reg_data = 0;
    
    BSP_Init();

    printf("Reader demo of FM175XX is drive by STM32 I2C!!!\r\n");
    
    FM175xx_HardReset();
	GetReg(JREG_VERSION,&reg_data);
	printf("IC Version = 0x%X.\r\n",reg_data);	

#ifdef READ_ALL_REGISTER_VALUE    
    printf( "ALL REG =  ");
    for( i=0; i<64; i++ )
    {
        GetReg( i,&status );
        printf( "%02X", status );
    }
    printf( "\r\n" );printf( "\r\n" );
#endif    
    
     	
    if(Check_Read_Write_FM175XX_FIFO() != SUCCESS)     //��֤SPI����д��FM175XX��FIFO���ض������Ƿ���ȷ
    {
        while(1)
        {        
            printf("Please check the SPI driver code or hardware connection.\r\n");
            Delay_ms( 1000 );       
        }  
    }   
    
    printf("Start polling.\r\n");
    
	while(1)
	{	
        Type_A_App();  
        Delay_ms( 200 );        
	}

}








